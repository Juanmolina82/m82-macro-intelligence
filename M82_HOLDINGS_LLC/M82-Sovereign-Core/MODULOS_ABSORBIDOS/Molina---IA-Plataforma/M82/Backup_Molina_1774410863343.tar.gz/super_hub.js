const express = require('express');
const https = require('https');
const fs = require('fs');
const { exec } = require('child_process');
const app = express();
const port = 8080;

let fleet = [
    { port: "JOSE", ship: "VLCC CARIBBEAN PRIDE", progress: 95, cargo: "MEREI 16", hours: 48, logged: false },
    { port: "CRP AMUAY", ship: "TANKER ZULIA", progress: 15, cargo: "NAPHTHA", hours: 8, logged: false }
];

let btcPrice = "74,250";
let totalBarrels = 4250000;

// Función de Respaldo Automático Estratégico
function autoBackup() {
    const fileName = `Backup_Molina_${new Date().getTime()}.tar.gz`;
    exec(`tar -czvf ${fileName} super_hub.js registro_exportaciones.txt`, (err) => {
        if (!err) console.log("📦 AUTO-BACKUP GENERADO: " + fileName);
    });
}

function logExport(ship, cargo, port) {
    const entry = `[${new Date().toLocaleString()}] AUDIT OK: ${ship} | PORT: ${port} | CARGO: ${cargo} | STATUS: DEPARTED\n`;
    fs.appendFileSync('registro_exportaciones.txt', entry);
    console.log("📝 REGISTRO AUDITADO: " + ship);
    autoBackup(); // Se respalda solo al completar operación
}

function updateLogistics() {
    fleet.forEach(s => {
        if (s.progress < 100) {
            s.progress += Math.floor(Math.random() * 5) + 2;
            if (s.progress >= 100) {
                s.progress = 100;
                if (!s.logged) { 
                    logExport(s.ship, s.cargo, s.port); 
                    s.logged = true; 
                    totalBarrels += 500000;
                }
            }
        } else if (Math.random() > 0.8) {
            s.progress = 0; s.logged = false;
            s.ship = "TANKER " + (Math.floor(Math.random() * 800) + 100);
        }
    });
}

function fetchBTC() {
    https.get('https://api.binance.com/api/3/ticker/price?symbol=BTCUSDT', (res) => {
        let data = '';
        res.on('data', (d) => { data += d; });
        res.on('end', () => {
            try { btcPrice = parseFloat(JSON.parse(data).price).toLocaleString(); } catch (e) {}
        });
    }).on('error', () => {});
}

setInterval(() => { updateLogistics(); fetchBTC(); }, 10000);

app.get('/', (req, res) => {
    let rows = fleet.map(s => `<tr><td>${s.port}</td><td>${s.ship}</td><td>${s.progress}%</td><td>${s.progress === 100 ? 'DEPARTED' : 'OPERATING'}</td></tr>`).join('');
    res.send(`<html><head><meta http-equiv="refresh" content="10"><style>body{background:#050505;color:#d4af37;font-family:sans-serif;padding:20px;}.card{border:1px solid #d4af37;padding:20px;background:#111;border-radius:10px;}table{width:100%;margin-top:20px;border-collapse:collapse;}td,th{padding:12px;border-bottom:1px solid #222;}</style></head>
    <body><div class="card"><h2>🏛️ MOLINA GLOBAL | AUTO-PILOT ACTIVE</h2><p>BTC: $${btcPrice} | VOL: ${totalBarrels.toLocaleString()} BBLS</p><table>${rows}</table></div></body></html>`);
});

app.listen(port, () => console.log('🚀 M82 EXECUTIVE AUTO-PILOT ONLINE'));
