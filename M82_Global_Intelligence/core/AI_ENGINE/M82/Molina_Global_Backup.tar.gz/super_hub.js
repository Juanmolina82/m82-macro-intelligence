const express = require('express');
const https = require('https');
const fs = require('fs');
const app = express();
const port = 8080;

let fleet = [
    { port: "JOSE", ship: "VLCC CARIBBEAN PRIDE", progress: 95, cargo: "MEREI 16", hours: 48, logged: false },
    { port: "CRP AMUAY", ship: "TANKER ZULIA", progress: 15, cargo: "NAPHTHA", hours: 8, logged: false },
    { port: "PLC", ship: "SUEZMAX AYACUCHO", progress: 42, cargo: "HAMACA", hours: 12, logged: false }
];

let btcPrice = "74,250";
let totalBarrels = 4250000;

function logExport(ship, cargo, port) {
    const entry = `[${new Date().toLocaleString()}] AUDIT OK: ${ship} | PORT: ${port} | CARGO: ${cargo} | STATUS: DEPARTED\n`;
    fs.appendFileSync('registro_exportaciones.txt', entry);
    console.log("📝 REGISTRO AUDITADO: " + ship);
}

function updateLogistics() {
    fleet.forEach(s => {
        if (s.progress < 100) {
            s.progress += Math.floor(Math.random() * 5) + 2;
            s.hours += 1;
            if (s.progress >= 100) {
                s.progress = 100;
                if (!s.logged) { 
                    logExport(s.ship, s.cargo, s.port); 
                    s.logged = true; 
                    totalBarrels += 500000;
                }
            }
        } else if (Math.random() > 0.8) {
            s.progress = 0; s.hours = 0; s.logged = false;
            s.ship = "TANKER " + (Math.floor(Math.random() * 800) + 100);
        }
    });
}

function fetchBTC() {
    https.get('https://api.binance.com/api/3/ticker/price?symbol=BTCUSDT', (res) => {
        let data = '';
        res.on('data', (d) => { data += d; });
        res.on('end', () => {
            try { btcPrice = parseFloat(JSON.parse(data).price).toLocaleString(); } catch (e) {}
        });
    }).on('error', () => {});
}

setInterval(() => { updateLogistics(); fetchBTC(); }, 10000);

app.get('/', (req, res) => {
    let rows = fleet.map(s => {
        const isDemurrage = s.progress >= 95 && s.hours > 36;
        return `<tr style="color:${isDemurrage ? '#ff4d4d' : '#eee'}">
            <td>${s.port}</td><td>${s.ship}</td><td>${s.progress}%</td>
            <td>${isDemurrage ? '⚠️ DEMURRAGE' : (s.progress === 100 ? 'DEPARTED' : 'OPERATING')}</td>
        </tr>`;
    }).join('');

    res.send(`
        <html>
        <head><meta http-equiv="refresh" content="10"><title>M82 LEDGER</title>
        <style>
            body { background: #050505; color: #d4af37; font-family: sans-serif; padding: 20px; }
            .card { border: 1px solid #d4af37; padding: 20px; border-radius: 12px; background: #111; }
            table { width: 100%; margin-top: 20px; border-collapse: collapse; }
            th { text-align: left; border-bottom: 2px solid #333; padding: 10px; }
            td { padding: 15px; border-bottom: 1px solid #222; }
            .ticker { position: fixed; bottom: 0; left: 0; width: 100%; background: #d4af37; color: #000; padding: 10px; font-weight: bold; overflow: hidden; }
        </style>
        </head>
        <body>
            <div class="card">
                <h2>🏛️ MOLINA GLOBAL LLC | MASTER LEDGER</h2>
                <div style="display:flex; gap:20px">
                    <p>BTC: <span style="color:#fff">$${btcPrice}</span></p>
                    <p>VOLUMEN ACUMULADO: <span style="color:#00ff00">${totalBarrels.toLocaleString()} BBLS</span></p>
                </div>
                <table>
                    <tr><th>PORT</th><th>VESSEL</th><th>LOAD</th><th>STATUS</th></tr>
                    ${rows}
                </table>
            </div>
            <div class="ticker">RULE OF LAW: ASYMMETRIC POSITION VERIFIED | OFAC COMPLIANCE: OK | DATA SYNCED</div>
        </body>
        </html>
    `);
});

app.listen(port, () => console.log('🏛️  M82 MASTER LEDGER ONLINE'));
